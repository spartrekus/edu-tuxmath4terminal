


//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
int ncwin_message( char *thetitle , char *themsg )
{
    int ch ; 
    int rows, cols;  
    int foo; 
    getmaxyx( stdscr, rows, cols);

    void mvfulllinereverse( int posyy )
    {
       attron(  A_REVERSE ); 
       for( foo = 0 ; foo <= cols-1 ; foo++) mvaddch( posyy , foo , ' ');
       attroff( A_REVERSE );
    }

    mvfulllinereverse( 0 ); 
    attron( A_REVERSE );
    mvprintw( 0, 0, "%s", thetitle );

    mvfulllinereverse( rows-1 ); 
    attron(  A_REVERSE ); 
    mvaddch( rows-1 , 1,  ' ' );
    printw( "DIALOG  ");
    addch(  ACS_DARROW);
    printw( ":j  ");
    addch(  ACS_UARROW);
    printw( ":k  ");
    addch(  ACS_ULCORNER );
    printw( ":g  ");
    addch(  ACS_DIAMOND);
    printw( ":o  ");
    attroff( A_REVERSE );

    attroff( A_REVERSE );
    mvfulllinereverse( rows-1 ); 
    attroff( A_REVERSE );

    attron(  A_REVERSE ); 
    ncrectangle( rows*25/100, cols * 25 /100, rows*75/100, cols * 75 /100 );
    ncframe( rows*25/100, cols * 25 /100, rows*75/100, cols * 75 /100 );

    attron(  A_REVERSE ); 
    mvprintw(rows *40/100+1, cols*30/100, "%s" , themsg);

    mvprintw( rows*70/100 -2 , cols*50/100 -3 , "| OK |" );
    attron(  A_REVERSE ); 

    getch();
   attroff(  A_REVERSE ); 
}






















//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////////////////////////////////////
//////////////
char *ncwin_inputbox( char *thetitle, char *themsg )
{
    int ch ; 
    int rows, cols;  
    int foo; 
    int i , j ; 
    char line[PATH_MAX]; 
    char charo[PATH_MAX]; 
    strncpy( line, "", PATH_MAX);
    strncpy( line , themsg , PATH_MAX );

    attroff( A_BOLD );
    attroff( A_REVERSE );
    color_set( 0 , NULL );

    void mvfulllinereverse( int posyy )
    {
       attron(  A_REVERSE ); 
       for( foo = 0 ; foo <= cols-1 ; foo++) mvaddch( posyy , foo , ' ');
       attroff( A_REVERSE );
    }
  
   void inputbox_draw()
   {
    getmaxyx( stdscr, rows, cols);
    //mvfulllinereverse( 0 ); 

    attron(  A_REVERSE ); 
    mvfulllinereverse( rows-1 ); 
    attron(  A_REVERSE ); 

    mvaddch( rows-1, 1,  ' ' );
    printw( "DIALOG  ");
    addch(  ACS_DARROW);
    printw( ":j  ");
    addch(  ACS_UARROW);
    printw( ":k  ");
    addch(  ACS_ULCORNER );
    printw( ":g  ");
    addch(  ACS_DIAMOND);
    printw( ":F10  ");

    //mvfulllinereverse( 0 ); 
    attron(  A_REVERSE ); 
    //mvprintw( 0, 0, "QUESTION" );

    attron(  A_REVERSE ); 
    ncrectangle( rows*25/100, cols * 25 /100, rows*75/100, cols * 75 /100 );
    ncframe( rows*25/100, cols * 25 /100, rows*75/100, cols * 75 /100 );

    attron(  A_REVERSE ); 
    mvprintw( rows*25/100+2, cols * 25 /100+2 , "%s", thetitle );

    mvprintw( rows*70/100 -2 , cols*50/100 -3 , "| OK |" );
    attron(  A_REVERSE ); 
    attroff(  A_REVERSE ); 

    attroff(  A_REVERSE ); 
    ncrectangle( rows*40/100+1, cols*30/100, rows*40/100+1, cols * 70 /100 );
    mvprintw( rows *40/100+1, cols*30/100, "%s" , line );
    attron(  A_REVERSE ); 
   }

    int foogameover = 0;
    while( foogameover == 0)
    {
      inputbox_draw();
      curs_set( 1 );
      ch = getch();
      switch( ch )
      {

       case KEY_GFUNCF10:
       case KEY_GCTRLE:
         strncpy( line , "" , PATH_MAX );
         foogameover = 1;
         break;

      	case KEY_GCTRLB:
          strncpy( line , "" , PATH_MAX );
          break;

      	case KEY_GBACKSPACE:
          strncpy( charo , strcut( line, 0, strlen( line ) -1 ) , PATH_MAX );
          strncpy( line , charo , PATH_MAX );
          break;

       case 10:
         foogameover = 1;
         break;

       default: 
        i = snprintf( charo, 5 , "%c", ch );
        strncat( line , charo , PATH_MAX - strlen( line ) -1 );
        break;
      } 
    }
    attroff(  A_REVERSE ); 

   size_t siz = sizeof line ; 
   char *r = malloc( sizeof line );
   return r ? memcpy(r, line, siz ) : NULL;
}





