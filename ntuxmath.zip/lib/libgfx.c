

void ncerase(  )
{
    int rows, cols;  
    getmaxyx( stdscr, rows, cols);
    int foo, fooy , foox ;
    int x1 = 0; int y1 = 0;  int x2 = cols-1 ;  int y2  = rows-1 ;
    for( fooy = y1 ; fooy <= y2 ; fooy++) 
    for( foo = x1 ; foo <= x2 ; foo++) 
         mvaddch( fooy , foo , ' ' );
}


void ncrectangle( int y1, int x1, int y2, int x2 )
{
    int foo, fooy , foox ;
    for( fooy = y1 ; fooy <= y2 ; fooy++) 
    for( foo = x1 ; foo <= x2 ; foo++) 
         mvaddch( fooy , foo , ' ' );
}


void nchspace( int y1, int x1 , int x2 )
{
    int foo, fooy , foox ;
    for( fooy = y1 ; fooy <= y1 ; fooy++) 
    for( foo = x1 ; foo <= x2 ; foo++) 
         mvaddch( fooy , foo , ' ' );
}


void nchline( int y1, int x1 , int x2 )
{
    int foo, fooy , foox ;
    for( fooy = y1 ; fooy <= y1 ; fooy++) 
    for( foo = x1 ; foo <= x2 ; foo++) 
         mvaddch( fooy , foo , ACS_HLINE );
}


void nchchar( int y1, int x1 , int x2 , int thechar )
{
    int foo, fooy , foox ;
    for( fooy = y1 ; fooy <= y1 ; fooy++) 
    for( foo = x1 ; foo <= x2 ; foo++) 
         mvaddch( fooy , foo , thechar );
}




void nccenttext( int y1, int x1, int x2, char *mytext )
{
    int foo, fooy , foox ;
    int textln = strlen( mytext );
    int midx = x1 + ( x2 - x1 ) /2;
    //for( fooy = y1 ; fooy <= y2 ; fooy++) 
    //for( foo = x1 ; foo <= x2 ; foo++) 
         mvprintw( y1 , midx - textln/2  , "%s", mytext );
}




void ncframe( int y1, int x1, int y2, int x2 )
{
    int foo, fooy , foox ;

    foo = x1;
    for( fooy = y1 ; fooy <= y2 ; fooy++) 
        mvaddch( fooy , foo , ACS_VLINE );

    foo = x2;
    for( fooy = y1 ; fooy <= y2 ; fooy++) 
         mvaddch( fooy , foo , ACS_VLINE );

    foo = y1;
    for( foox = x1 ; foox <= x2 ; foox++) 
         mvaddch( foo , foox , ACS_HLINE );

    foo = y2;
    for( foox = x1 ; foox <= x2 ; foox++) 
         mvaddch( foo , foox , ACS_HLINE );

    mvaddch( y1 , x1 , ACS_ULCORNER );
    mvaddch( y1 , x2 , ACS_URCORNER );
    mvaddch( y2 , x1 , ACS_LLCORNER );
    mvaddch( y2 , x2 , ACS_LRCORNER );
}

