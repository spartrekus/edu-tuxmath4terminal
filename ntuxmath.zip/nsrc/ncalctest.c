
////////////////////////////////
////////////////////////////////
// ncalctest 
////////////////////////////////
////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
//#include <unistd.h>
#include <string.h>
#include <string.h>

// #define PAMAX 250

// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#include <unistd.h>  //define getcwd

#include <ncurses.h>


#include <time.h>


#include "../lib/libcore.c"
#include "../lib/libtime.c"
#include "../lib/libncurse.c"
#include "../lib/libkey.c"
#include "../lib/libgfx.c"
#include "../lib/libdialog.c"


// the random function
int RandomNumberGenerator(const int nMin,const int nMax,const int  nNumOfNumsToGenerate)
{
  int nRandonNumber = 0;
  int i ; 
  for (i = 0; i < nNumOfNumsToGenerate; i++)
   {
          nRandonNumber = rand()%(nMax-nMin) + nMin;
   }
   // printf(“%d “, nRandonNumber);
   return nRandonNumber; 
}

   int rows, cols;  
   void mvfulllinereverse( int posyy ){
    attron(  A_REVERSE ); 
    int foo;
    for( foo = 0 ; foo <= cols-1 ; foo++) mvaddch( posyy , foo , ' ');
    attroff( A_REVERSE );
   }



int main( int argc, char *argv[])
{	
    char line[250];
    char cmdi[PATH_MAX];
    char charo[PATH_MAX];
    char charoout[PATH_MAX];
    int  fooint;
    char gametype[PATH_MAX];
    int  i;
    strncpy( gametype , " vim " , PATH_MAX );
    char filetarget[250];
    char idata[1240][250];
    char cwd[PATH_MAX];
    char pathbefore[PATH_MAX];
    strncpy( pathbefore , getcwd( cwd, PATH_MAX ) , PATH_MAX );
    int foo ;
    unsigned filemax = 0;
    unsigned n=0;
    DIR *dirp;
    struct dirent *dp;
    int selection = 0 ; 
    int selectionmax = 0 ; 
    int scrolly=0; 

    initscr();			
    curs_set( 0 );

  FILE *fp;

  noecho();            
  keypad( stdscr, TRUE ); 
  start_color();
  init_pair(0,  COLOR_WHITE,     COLOR_BLACK);
  init_pair(1,  COLOR_RED,     COLOR_BLACK);
  init_pair(2,  COLOR_GREEN,   COLOR_BLACK);
  init_pair(3,  COLOR_YELLOW,  COLOR_BLACK);
  init_pair(4,  COLOR_BLUE,    COLOR_BLACK);
  init_pair(5,  COLOR_MAGENTA, COLOR_BLACK);
  init_pair(6,  COLOR_CYAN,    COLOR_BLACK);
  init_pair(7,  COLOR_BLUE,    COLOR_WHITE);
  init_pair(8,  COLOR_WHITE,   COLOR_RED);
  init_pair(9,  COLOR_BLACK,   COLOR_GREEN);
  init_pair(10, COLOR_BLUE,  COLOR_YELLOW   );
  init_pair(11, COLOR_WHITE,   COLOR_BLUE);
  init_pair(12, COLOR_YELLOW,   COLOR_BLUE);
  init_pair(13, COLOR_BLACK,   COLOR_CYAN);
  init_pair(14, COLOR_BLUE,   COLOR_GREEN);
  init_pair(15, COLOR_BLUE, COLOR_CYAN );
  init_pair(16, COLOR_CYAN, COLOR_WHITE );
  init_pair(17, COLOR_CYAN, COLOR_YELLOW );
  init_pair(18, COLOR_CYAN, COLOR_BLUE);
  init_pair( 19, COLOR_MAGENTA , COLOR_BLUE);
  init_pair( 20 , COLOR_RED , COLOR_BLUE);
  init_pair( 21 , COLOR_BLUE , COLOR_YELLOW);
  init_pair( 22, COLOR_YELLOW,   COLOR_CYAN);
  init_pair( 23, COLOR_WHITE, COLOR_BLUE);

    int ch ; 
    getmaxyx( stdscr, rows, cols);

   int resultval = 0;
   int resultok = 0;
   int resultko = 0;
   int mylevel = 1;
   
   void drawit()
   {
    color_set( 0, NULL );
    mvfulllinereverse( 0 );


    attroff( A_REVERSE );
    mvprintw( 1, 0, "Please calculate: " );

    attroff( A_REVERSE );
    mvprintw( 3, 0, "                 " );

    attron( A_REVERSE );
    int valc1, valc2 ; 
    valc1 = 3;
    valc2 = 3;

    int mylevelmax = 10;
    if ( mylevel == 1 ) mylevelmax = 10;
    if ( mylevel == 2 ) mylevelmax = 15;
    if ( mylevel == 3 ) mylevelmax = 20;
    if ( mylevel == 4 ) mylevelmax = 25;

    srand(time(NULL));
    valc1 = RandomNumberGenerator(1, mylevelmax ,15) ;
    srand(time(NULL));
    valc2 = RandomNumberGenerator(1, mylevelmax ,25) ;
    printw( " %d + %d " , valc1, valc2 ) ;

    color_set( 0, NULL );
    attroff( A_REVERSE );
    nchspace( rows-2 ,  0, cols-1);
    color_set( 0, NULL );
    mvprintw( rows-2, 0, "|LEVEL:%d |OK:", mylevel );
    color_set( 2, NULL );
    printw ( "%d" , resultok );
    color_set( 0, NULL );
    printw( "| KO:");
    color_set( 1, NULL );
    printw( "%d", resultko  );
    color_set( 0, NULL );
    printw( "|" );
    color_set( 0, NULL );

    attroff( A_REVERSE );
    strncpy( cwd, ncwin_inputbox( "Enter Number",  "" ), PATH_MAX );

    /// if you have the key 'l' on your keyboard
    if ( strcmp( cwd , "level 1" ) == 0 ) 
    { mylevel = 1; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "level 2" ) == 0 ) 
    { mylevel = 2; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "level 3" ) == 0 ) 
    { mylevel = 3; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "level 4" ) == 0 ) 
    { mylevel = 4; strncpy( cwd, "", PATH_MAX ); }
    /// if you have no key 'l' on your keyboard
    else if ( strcmp( cwd , "eve 1" ) == 0 ) 
    { mylevel = 1; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "eve 2" ) == 0 ) 
    { mylevel = 2; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "eve 3" ) == 0 ) 
    { mylevel = 3; strncpy( cwd, "", PATH_MAX ); }
    else if ( strcmp( cwd , "eve 4" ) == 0 ) 
    { mylevel = 4; strncpy( cwd, "", PATH_MAX ); }
    
    resultval = -1;
    if ( strcmp( cwd , "" ) != 0 ) 
    {
          fooint = snprintf( charo, 50 , "%d", valc1 + valc2 );
          strncpy( cmdi, "", PATH_MAX );
          strncat( cmdi , "Solution: "  , PATH_MAX - strlen( cmdi ) -1 );
          strncat( cmdi ,  charo  , PATH_MAX - strlen( cmdi ) -1 );

          color_set( 0, NULL );

	  if ( atoi( cwd ) == valc1 + valc2 )  
	  {
	    resultok++;
	    resultval = 1;
	  }
	  else
	  {
	    resultko++;
	    resultval = 0;
	  }

         chdir( getenv( "HOME" ) );
	 fp = fopen( ".ncalctest.log" , "ab+" );
           fooint = snprintf( charoout , 80 , "%d+%d=?; USER:%s", valc1 , valc2 , cwd );
           fputs( strtimestamp(), fp );
	   fputs( ";" , fp );
	   fputs( charoout , fp );
	   fputs( "\n" , fp );
	 fclose( fp );

	 if ( resultval == 0 )
	 {
	    nruncmd( " clear ; pkill aplay ; cd ; cd coding/tinybox/sounds ; screen -d -m  aplay buzz.wav " );
            color_set( 1, NULL );
            ncwin_message( "MESSAGE: False", cmdi );
	 }
	 else if ( resultval == 1 )
	 {
	    nruncmd( " clear ; pkill aplay ; cd ; cd coding/tinybox/sounds ; screen -d -m  aplay cheer.wav " );
            color_set( 2, NULL );
            ncwin_message( "MESSAGE: False", cmdi );
	 }

       }
    }
    
    while( 1 )
      drawit();

    curs_set( 1 );
    endwin();			/* End curses mode		  */
    return 0;
}


